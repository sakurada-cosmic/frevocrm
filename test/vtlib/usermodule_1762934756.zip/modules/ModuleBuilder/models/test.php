<?php
use ZipArchive;
//echo '<pre>';print_r(get_defined_constants(true));
		if(!class_exists(ZipArchive))
			{
				 $zipflag = 1;
			}
		elseif(!class_exists(DOMDocument))
			{
				$domflag = 1;			
            }
            
            ?>